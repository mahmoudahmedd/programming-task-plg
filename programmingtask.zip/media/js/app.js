function myFunction() {
  document.getElementById("myDIV").style.display = "none";
}